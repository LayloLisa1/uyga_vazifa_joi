const Category = require('../models/categoryModel');
exports.getAllCategories = async () => {
  try {
    const categories = await Category.find();
    return categories;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.createCategory = async (categoryData) => {
  try {
    const category = new Category(categoryData);
    await category.save();
    return category;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.getCategoryById = async (categoryId) => {
  try {
    const category = await Category.findById(categoryId);
    if (!category) {
      throw new Error('Kategoriya topilmadi');
    }
    return category;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.updateCategory = async (categoryId, categoryData) => {
  try {
    const category = await Category.findByIdAndUpdate(categoryId, categoryData, { new: true });
    if (!category) {
      throw new Error('Kategoriya topilmadi');
    }
    return category;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.deleteCategory = async (categoryId) => {
  try {
    const category = await Category.findByIdAndDelete(categoryId);
    if (!category) {
      throw new Error('Kategoriya topilmadi');
    }
  } catch (error) {
    throw new Error(error.message);
  }
};
