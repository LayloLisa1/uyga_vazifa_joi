const Author = require('../models/authorModel');
exports.getAllAuthors = async () => {
  try {
    const authors = await Author.find();
    return authors;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.createAuthor = async (authorData) => {
  try {
    const author = new Author(authorData);
    await author.save();
    return author;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.getAuthorById = async (authorId) => {
  try {
    const author = await Author.findById(authorId);
    if (!author) {
      throw new Error('Avtor topilmadi');
    }
    return author;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.updateAuthor = async (authorId, authorData) => {
  try {
    const author = await Author.findByIdAndUpdate(authorId, authorData, { new: true });
    if (!author) {
      throw new Error('Avtor topilmadi');
    }
    return author;
  } catch (error) {
    throw new Error(error.message);
  }
};
exports.deleteAuthor = async (authorId) => {
  try {
    const author = await Author.findByIdAndDelete(authorId);
    if (!author) {
      throw new Error('Avtor topilmadi');
    }
  } catch (error) {
    throw new Error(error.message);
  }
};
