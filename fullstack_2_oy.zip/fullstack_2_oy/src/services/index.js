import User from "../models/index.js";

export const saveUser = async (email, password) => {
    const user = new User({ email, password });
    return user.save();
};
