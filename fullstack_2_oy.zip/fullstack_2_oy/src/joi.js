const Joi = require("joi");
const { saveUser } = require("../services/index.js");

module.exports.registerController = async (req, res) => {
    const { email, username, password, confirmPassword, gender, birthday } = req.body;

    const schema = Joi.object({
        email: Joi.string().email().required(),
        username: Joi.string().min(5).max(20).required(),
        password: Joi.string().min(5).max(10).required(),
        confirmPassword: Joi.string().min(5).max(10).required().valid(Joi.ref('password')),
        gender: Joi.string().required(),
        birthday: Joi.date().max('2004-01-01').iso()
    });
    const { error } = schema.validate(req.body);

    if (error) {
        return res.status(400).json({ message: error.details[0].message });
    }

    try {
        const user = await saveUser(email, password);
        return res.json(user);
    } catch (err) {
        return res.status(500).json({ message: "Serverda xatolik yuz berdi." });
    }
};
