import mongoose from "mongoose";

const {
    Schema,
    model
} = mongoose;

const userSchema = new Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        min: 5,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

export default model('User', userSchema);
