export const loginController = (req, res) => {
    res.send("loginController")
}