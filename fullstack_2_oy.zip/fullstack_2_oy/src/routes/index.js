import loginRoute from "./login.route.js"
import registerRoute from "./register.route.js"

export {
    registerRoute,
    loginRoute
}